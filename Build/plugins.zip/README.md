# Cadet

[![Cadet-Final.png](https://i.postimg.cc/CMmJGT2x/Cadet-Final.png)]()

# Skills

[![Screenshot-2024-07-13-214240.png](https://i.postimg.cc/rFfCJdBg/Screenshot-2024-07-13-214240.png)]()

[![Screenshot-2024-07-12-151352.png](https://i.postimg.cc/YqXM3LDj/Screenshot-2024-07-12-151352.png)]()

Cadet concept and everything before the revival - Ruxbieno

Models and Animations - Dotflare

Icons - synodii

Revival (Code, skills and everything else) - Tsuyoikenko