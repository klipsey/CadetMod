# Cadet

[![Cadet-Final.png](https://i.postimg.cc/CMmJGT2x/Cadet-Final.png)]()

# Skills

## ICONS WIP

[![Screenshot-2024-07-11-152608.png](https://i.postimg.cc/CMN4Hrsm/Screenshot-2024-07-11-152608.png)]()

[![Screenshot-2024-07-11-152627.png](https://i.postimg.cc/5N2SP5P1/Screenshot-2024-07-11-152627.png)]()

Cadet concept and everything before the revival - Ruxbieno

Models and Animations - Dotflare

Icons - synodii

Revival (Code, skills and everything else) - Tsuyoikenko