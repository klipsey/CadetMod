# Cadet

[![Cadet-Final.png](https://i.postimg.cc/CMmJGT2x/Cadet-Final.png)]()

# Skills

[![Screenshot-2024-07-13-214240.png](https://i.postimg.cc/rFfCJdBg/Screenshot-2024-07-13-214240.png)]()

[![Screenshot-2024-07-17-162410.png](https://i.postimg.cc/XYg4v0pL/Screenshot-2024-07-17-162410.png)]()

[![Screenshot-2024-07-17-162415.png](https://i.postimg.cc/N0fY9PXc/Screenshot-2024-07-17-162415.png)]()

[![Screenshot-2024-07-12-151352.png](https://i.postimg.cc/YqXM3LDj/Screenshot-2024-07-12-151352.png)]()

Cadet concept and everything before - Ruxbieno

Cadet Base Model and Animations - Dotflare

Icons - synodii

Item Displays - KoalaWalls

Mastery Skin Design - rekka

Everything else - Tsuyoikenko