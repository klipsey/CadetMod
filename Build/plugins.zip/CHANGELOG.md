# 1.1.7

- Fixed Ragdoll

# 1.1.6

- Sots

# 1.1.5

- Fixed base skin gun not appearing?? (why tf does it keep doing this)

# 1.1.4

- Changed / added new special from old cadets concept and retired old special to alt special
- Changed some tokens to old cadet concept tokens
- Readded Emotes. 1 or 2 to activate by default

# 1.1.3

- Token fixes

# 1.1.2

- Fixed mastery skin dealing double damage on gun throw
- Fixed robot texturing on mastery skin

# 1.1.1 

- Read Me

# 1.1.0

- Mastery skin
- Alt primary and alt secondary nerfs

# 1.0.9

- Fixed stuns, shocks, freezes etc not working

# 1.0.8 

- Item Displays

# 1.0.7

- Added two new alt skills

# 1.0.6

- Fixed leftover frame in sprint

# 1.0.5

- Animation polish by dotflare! (Jump, sprint, landing and more)

# 1.0.4

- Updated Read me

# 1.0.3

- Added skill icons courtesy of synodii

# 1.0.2

- Fixed holding r not working / canceling itself

# 1.0.1

- Credits

# 1.0.0

- The Pac is Bac