# 1.0.8 

- i tem

# 1.0.7

- Added two new alt skills

# 1.0.6

- Fixed leftover frame in sprint

# 1.0.5

- Animation polish by dotflare! (Jump, sprint, landing and more)

# 1.0.4

- Updated Read me

# 1.0.3

- Added skill icons courtesy of synodii

# 1.0.2

- Fixed holding r not working / canceling itself

# 1.0.1

- Credits

# 1.0.0

- The Pac is Bac