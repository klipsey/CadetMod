# 1.0.3

- Added skill icons courtesy of synodii

# 1.0.2

- Fixed holding r not working / canceling itself

# 1.0.1

- Credits

# 1.0.0

- The Pac is Bac